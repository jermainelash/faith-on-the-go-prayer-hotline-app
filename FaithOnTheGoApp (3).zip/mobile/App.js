import React from 'react';
import { StyleSheet, Text, View, TextInput, Button, ScrollView, Linking } from 'react-native';

export default function App() {
  const handleCall = () => {
    Linking.openURL('tel:3364333428');
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Faith on the Go Prayer Hotline</Text>

      <Text style={styles.sectionTitle}>Submit a Prayer Request</Text>
      <TextInput style={styles.input} placeholder="Your Name" />
      <TextInput style={styles.input} placeholder="Your Prayer Request" multiline />
      <Button title="Submit Request" onPress={() => alert('Prayer request submitted')} />

      <Text style={styles.sectionTitle}>Call a Prayer Partner</Text>
      <Button title="Call Now" onPress={handleCall} />

      <Text style={styles.sectionTitle}>Daily Devotional</Text>
      <Text style={styles.devotional}>
        "Now faith is the substance of things hoped for, the evidence of things not seen." - Hebrews 11:1
      </Text>

      <Text style={styles.sectionTitle}>Encouragement Notifications</Text>
      <Text>Push notifications will appear here (placeholder).</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, marginTop: 40 },
  header: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginTop: 20 },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 10, marginVertical: 10 },
  devotional: { fontStyle: 'italic', marginVertical: 10 }
});